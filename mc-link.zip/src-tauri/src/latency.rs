use std::net::TcpStream;
use std::time::{Duration, Instant};
use std::net::SocketAddr;
use std::io::{Read, Write};

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct RelayWithLatency {
    pub id: String,
    pub name: String,
    pub address: String,
    pub latency_ms: Option<u64>,
}

fn resolve_address(addr_str: &str) -> Option<SocketAddr> {
    if let Ok(addr) = addr_str.parse::<SocketAddr>() {
        return Some(addr);
    }

    let parts: Vec<&str> = addr_str.rsplitn(2, ':').collect();
    if parts.len() != 2 {
        return None;
    }

    let port = match parts[0].parse::<u16>() {
        Ok(p) => p,
        Err(_) => return None,
    };

    let hostname = parts[1];

    match std::net::ToSocketAddrs::to_socket_addrs(&(hostname, port)) {
        Ok(mut addrs) => addrs.next(),
        Err(_) => None,
    }
}

fn read_packet(stream: &mut TcpStream) -> std::io::Result<Vec<u8>> {
    let mut len_buf = [0u8; 4];
    stream.read_exact(&mut len_buf)?;
    let len = u32::from_be_bytes(len_buf) as usize;
    let mut buf = vec![0u8; len];
    stream.read_exact(&mut buf)?;
    Ok(buf)
}

fn write_packet(stream: &mut TcpStream, data: &[u8]) -> std::io::Result<()> {
    let len_buf = (data.len() as u32).to_be_bytes();
    stream.write_all(&len_buf)?;
    stream.write_all(data)?;
    Ok(())
}

pub async fn test_relay_latency(address: &str) -> Option<u64> {
    let addr: SocketAddr = match resolve_address(address) {
        Some(a) => a,
        None => return None,
    };

    let start = Instant::now();
    
    match TcpStream::connect(&addr) {
        Ok(mut stream) => {
            stream.set_read_timeout(Some(Duration::from_secs(2))).ok()?;
            
            let mut packet = vec![0x32];
            write_packet(&mut stream, &packet).ok()?;
            
            if read_packet(&mut stream).is_ok() {
                let elapsed = start.elapsed();
                return Some(elapsed.as_millis() as u64);
            }
        }
        Err(_) => {}
    }

    None
}

pub async fn select_best_relay(relays: &[RelayWithLatency]) -> Option<&RelayWithLatency> {
    let available_relays: Vec<&RelayWithLatency> = relays.iter()
        .filter(|r| r.latency_ms.is_some())
        .collect();

    if !available_relays.is_empty() {
        available_relays.into_iter().min_by_key(|r| r.latency_ms.unwrap())
    } else {
        relays.first()
    }
}
