mod host;
mod client;
mod crypto;
mod latency;
mod routing;

use std::sync::Mutex;
use host::HostMode;
use client::ClientMode;
use latency::RelayWithLatency;
use routing::{RelayTopology, RelayNode};
use std::net::{SocketAddr, TcpStream};
use std::time::{Duration, Instant};
use serde::{Serialize, Deserialize};
use tauri::{Emitter, Manager};
use std::io::{Read, Write};

const CENTRAL_SERVER_ADDR: &str = "127.0.0.1:57895";

fn resolve_address(addr_str: &str) -> Option<SocketAddr> {
    if let Ok(addr) = addr_str.parse::<SocketAddr>() {
        return Some(addr);
    }

    let parts: Vec<&str> = addr_str.rsplitn(2, ':').collect();
    if parts.len() != 2 {
        return None;
    }

    let port = match parts[0].parse::<u16>() {
        Ok(p) => p,
        Err(_) => return None,
    };

    let hostname = parts[1];

    match std::net::ToSocketAddrs::to_socket_addrs(&(hostname, port)) {
        Ok(mut addrs) => addrs.next(),
        Err(_) => None,
    }
}

fn read_packet(stream: &mut TcpStream) -> std::io::Result<Vec<u8>> {
    let mut len_buf = [0u8; 4];
    stream.read_exact(&mut len_buf)?;
    let len = u32::from_be_bytes(len_buf) as usize;
    let mut buf = vec![0u8; len];
    stream.read_exact(&mut buf)?;
    Ok(buf)
}

fn write_packet(stream: &mut TcpStream, data: &[u8]) -> std::io::Result<()> {
    let len_buf = (data.len() as u32).to_be_bytes();
    stream.write_all(&len_buf)?;
    stream.write_all(data)?;
    Ok(())
}

pub struct AppState {
    host_mode: Mutex<Option<HostMode>>,
    client_mode: Mutex<Option<ClientMode>>,
    current_room: Mutex<Option<(String, String)>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct RelayInfo {
    id: String,
    name: String,
    address: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct RoomInfo {
    name: String,
    password_hash: String,
    host_relay_id: String,
    created_at: u64,
}

#[derive(Serialize, Clone)]
struct LanServerInfo {
    motd: String,
    port: u16,
}

fn serialize<T: Serialize>(data: &T) -> Vec<u8> {
    serde_json::to_vec(data).unwrap_or_default()
}

fn deserialize<'a, T: Deserialize<'a>>(data: &'a [u8]) -> Option<T> {
    serde_json::from_slice(data).ok()
}

fn send_request(cmd: u8, data: &[u8]) -> Option<Vec<u8>> {
    let central_addr: SocketAddr = match resolve_address(CENTRAL_SERVER_ADDR) {
        Some(addr) => addr,
        None => return None,
    };
    
    let mut stream = match TcpStream::connect(&central_addr) {
        Ok(s) => s,
        Err(_) => return None,
    };
    
    let mut packet = vec![cmd];
    packet.extend_from_slice(data);
    
    write_packet(&mut stream, &packet).ok()?;
    
    stream.set_read_timeout(Some(Duration::from_secs(5))).ok()?;
    
    match read_packet(&mut stream) {
        Ok(buf) => Some(buf),
        Err(_) => None,
    }
}

fn get_relays() -> Option<Vec<RelayInfo>> {
    let response = send_request(0x12, &[])?;
    if response.len() > 0 && response[0] == 0x13 {
        deserialize(&response[1..])
    } else {
        None
    }
}

fn get_topology() -> Option<RelayTopology> {
    let response = send_request(0x15, &[])?;
    if response.len() > 0 && response[0] == 0x16 {
        let topology_data: serde_json::Value = deserialize(&response[1..])?;
        let relays_data = topology_data.get("relays")?.as_array()?;
        let matrix_data = topology_data.get("latency_matrix")?.as_object()?;
        
        let mut relays = Vec::new();
        for r in relays_data {
            relays.push(RelayNode {
                id: r.get("id")?.as_str()?.to_string(),
                address: r.get("address")?.as_str()?.to_string(),
            });
        }
        
        let mut latency_matrix = std::collections::HashMap::new();
        for (from, tos) in matrix_data {
            let mut inner_map = std::collections::HashMap::new();
            let tos = tos.as_object()?;
            for (to, latency) in tos {
                inner_map.insert(to.to_string(), latency.as_u64()?);
            }
            latency_matrix.insert(from.to_string(), inner_map);
        }
        
        Some(RelayTopology { relays, latency_matrix })
    } else {
        None
    }
}

fn create_room(room_name: &str, password: &str, relay_id: &str) -> Option<RoomInfo> {
    let req = serde_json::json!({
        "room_name": room_name,
        "password": password,
        "relay_id": relay_id,
    });
    let response = send_request(0x20, &serialize(&req))?;
    if response.len() > 1 && response[0] == 0x21 && response[1] == 0x00 {
        deserialize(&response[2..])
    } else {
        None
    }
}

fn get_room(room_name: &str) -> Option<(bool, Option<RoomInfo>)> {
    let req = serde_json::json!({ "room_name": room_name });
    let response = send_request(0x22, &serialize(&req))?;
    if response.len() > 0 && response[0] == 0x23 {
        let room_data: serde_json::Value = deserialize(&response[1..])?;
        let exists = room_data.get("exists")?.as_bool()?;
        let room = room_data.get("room")?;
        
        if exists {
            let room_info: RoomInfo = serde_json::from_value(room.clone()).ok()?;
            Some((true, Some(room_info)))
        } else {
            Some((false, None))
        }
    } else {
        None
    }
}

fn delete_room(room_name: &str, password: &str) -> bool {
    let req = serde_json::json!({
        "room_name": room_name,
        "password": password,
    });
    if let Some(response) = send_request(0x24, &serialize(&req)) {
        return response.len() >= 2 && response[0] == 0x25 && response[1] == 0x00;
    }
    false
}

fn scan_lan_servers_sync() -> Result<Vec<LanServerInfo>, String> {
    let host = HostMode::new();
    let servers = host.scan_lan_servers()?;
    
    let info_list: Vec<LanServerInfo> = servers.into_iter()
        .map(|s| LanServerInfo { motd: s.motd, port: s.port })
        .collect();
    
    Ok(info_list)
}

#[tauri::command]
fn scan_lan_servers() -> Result<Vec<LanServerInfo>, String> {
    scan_lan_servers_sync()
}

#[tauri::command]
async fn start_online(
    state: tauri::State<'_, AppState>,
    room_name: String,
    password: String,
    window: tauri::Window,
) -> Result<String, String> {
    let servers = scan_lan_servers_sync()?;
    
    let mut mc_port = 0;
    let mut mc_motd = String::new();
    
    if let Some(server) = servers.first() {
        mc_port = server.port;
        mc_motd = server.motd.clone();
    }
    
    window.emit("app-log", "正在获取拓扑信息...").ok();
    
    let topology = match get_topology() {
        Some(t) => t,
        None => return Err("获取拓扑失败".to_string()),
    };
    
    if topology.relays.is_empty() {
        return Err("没有可用的中继服务器".to_string());
    }
    
    window.emit("app-log", format!("找到 {} 个中继服务器，正在测试延迟...", topology.relays.len())).ok();
    
    let mut relays_with_latency = Vec::new();
    for relay in &topology.relays {
        let latency = latency::test_relay_latency(&relay.address).await;
        relays_with_latency.push(RelayWithLatency {
            id: relay.id.clone(),
            name: relay.address.clone(),
            address: relay.address.clone(),
            latency_ms: latency,
        });
    }
    
    let my_best_relay = latency::select_best_relay(&relays_with_latency).await;
    
    let my_relay_id = match my_best_relay {
        Some(r) => r.id.clone(),
        None => return Err("没有可用的中继服务器".to_string()),
    };
    
    let my_relay_addr = match my_best_relay {
        Some(r) => r.address.clone(),
        None => return Err("没有可用的中继服务器".to_string()),
    };
    
    window.emit("app-log", format!("选择的本地中继: {} (延迟: {}ms)", 
        my_relay_addr, my_best_relay.as_ref().unwrap().latency_ms.unwrap_or(0))).ok();
    
    let room_exists = get_room(&room_name).ok_or("无法查询房间")?;
    
    if room_exists.0 {
        let room = room_exists.1.ok_or("房间不存在".to_string())?;
        if room.password_hash != password {
            return Err("房间名或密码错误".to_string());
        }
        
        window.emit("app-log", format!("加入房间: {}", room_name)).ok();
        
        let addr: SocketAddr = resolve_address(&my_relay_addr).ok_or("无效的中继地址".to_string())?;
        
        let mut client = ClientMode::new(addr, 25565, format!("房间: {}", room_name));
        client.set_relay(addr, room_name.clone(), password.clone());
        
        let window_clone = window.clone();
        client.set_log_callback(move |msg| {
            let _ = window_clone.emit("app-log", msg);
        });
        
        let result = client.start()?;
        *state.client_mode.lock().unwrap() = Some(client);
        *state.current_room.lock().unwrap() = Some((room_name, password));
        
        return Ok(result);
    } else {
        let _ = create_room(&room_name, &password, &my_relay_id);
        window.emit("app-log", format!("创建房间: {}", room_name)).ok();
        
        let addr: SocketAddr = resolve_address(&my_relay_addr).ok_or("无效的中继地址".to_string())?;
        
        let mut host = HostMode::new();
        host.set_relay(addr, room_name.clone(), password.clone());
        host.set_relay_id(my_relay_id);
        
        let window_clone = window.clone();
        host.set_log_callback(move |msg| {
            let _ = window_clone.emit("app-log", msg);
        });
        
        let window_clone2 = window.clone();
        host.set_test_callback(move || {
            let _ = window_clone2.emit("test-received", "");
        });
        
        if servers.is_empty() {
            return Err("未找到Minecraft局域网服务器，请先开启".to_string());
        }
        
        let result = host.start(mc_port, mc_motd)?;
        *state.host_mode.lock().unwrap() = Some(host);
        *state.current_room.lock().unwrap() = Some((room_name, password));
        
        return Ok(result);
    }
}

#[tauri::command]
fn stop_online(state: tauri::State<AppState>) -> Result<String, String> {
    let (room_name, password) = {
        let current_room = state.current_room.lock().unwrap();
        if let Some((name, pass)) = current_room.clone() {
            (Some(name), Some(pass))
        } else {
            (None, None)
        }
    };

    if let (Some(name), Some(pass)) = (room_name, password) {
        if state.host_mode.lock().unwrap().is_some() {
            if delete_room(&name, &pass) {
                println!("房间已注销: {}", name);
            }
        }
    }

    if let Some(ref mut host) = *state.host_mode.lock().unwrap() {
        host.stop();
    }
    *state.host_mode.lock().unwrap() = None;
    
    if let Some(ref mut client) = *state.client_mode.lock().unwrap() {
        client.stop();
    }
    *state.client_mode.lock().unwrap() = None;
    
    *state.current_room.lock().unwrap() = None;
    
    Ok("联机已停止".to_string())
}

#[tauri::command]
fn test_connection(state: tauri::State<AppState>) -> Result<String, String> {
    if let Some(ref host) = *state.host_mode.lock().unwrap() {
        host.send_test_packet();
        return Ok("已发送测试数据包到Minecraft服务器".to_string());
    }
    if let Some(ref client) = *state.client_mode.lock().unwrap() {
        client.send_test_packet();
        return Ok("已发送测试数据包到中继服务器".to_string());
    }
    Err("未处于联机状态".to_string())
}

#[tauri::command]
fn minimize_window(window: tauri::Window) {
    window.minimize().ok();
}

#[tauri::command]
fn maximize_window(window: tauri::Window) {
    if window.is_maximized().unwrap_or(false) {
        window.unmaximize().ok();
    } else {
        window.maximize().ok();
    }
}

#[tauri::command]
fn close_window(state: tauri::State<AppState>, window: tauri::Window) {
    let mut host_mode = state.host_mode.lock().unwrap();
    if host_mode.is_some() {
        host_mode.as_mut().unwrap().stop();
        *host_mode = None;
    }
    
    let mut client_mode = state.client_mode.lock().unwrap();
    if client_mode.is_some() {
        client_mode.as_mut().unwrap().stop();
        *client_mode = None;
    }
    
    *state.current_room.lock().unwrap() = None;
    
    window.close().ok();
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .manage(AppState {
            host_mode: Mutex::new(None),
            client_mode: Mutex::new(None),
            current_room: Mutex::new(None),
        })
        .invoke_handler(tauri::generate_handler![
            scan_lan_servers,
            start_online,
            stop_online,
            test_connection,
            minimize_window,
            maximize_window,
            close_window
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
